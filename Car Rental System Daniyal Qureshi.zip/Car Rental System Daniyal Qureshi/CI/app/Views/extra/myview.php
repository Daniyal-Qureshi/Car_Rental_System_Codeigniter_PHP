<html>

<body>
<form action="CI/public/index.php/recieve" method="post">
<input type="text" name="Id">
<input type="password" name="password">
<input type="submit" value="submit">
</form>


</body>
</html>