<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>

<form action="CI/public/index.php/home" method="post">
<fieldset>
	<legend>Login Form</legend>
<input type="text" name="uname" placeholder="Enter your name">
<input type="password" name="password" placeholder="Enter password">

<button>Submit</button>
</fieldset>
</form>

</body>
</html>