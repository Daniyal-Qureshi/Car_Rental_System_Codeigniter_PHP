<?php namespace App\Controllers;

class send extends BaseController
{
	public function index()
	{
	
		return view('myview');
		

	}


	//--------------------------------------------------------------------

}
